The CollisionResistance.java program collision resistance of the hash function. By use the brute-force method to see how long it takes to break this property. 

How to run program in Linux

1.Download ZIP fil "One-way-hash"
2.Unzip the file "One-way-hash"
3.Open the "Terminal"
4.Go to the file "One-way-hash"   
5.Start with compile and run the program as:

javac CollisionResistance.java
Java CollisionResistance

6.Then "Enter YOUR MESSAGE TO DIGEST:" 

7. To stop the program use CTRL+C
